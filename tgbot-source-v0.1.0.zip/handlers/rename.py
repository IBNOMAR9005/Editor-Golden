"""إعادة التسمية ⭐: أي ملف، الامتداد محفوظ تلقائيًا (وممكن يتغيّر)، اسم ذكي بضغطة، بدون تنزيل/رفع زيادة."""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.filters import Filter
from aiogram.types import CallbackQuery, Message

from core.progress import Reporter, edit_safe, ticker
from core.queue import Job, UserError
from core.sender import send_file
from core.state import Dialog, Dialogs
from core.utils import build_final_name, esc, human_elapsed, human_size, smart_name, split_ext
from handlers.common import need_session, safe_delete
from ui import keyboards as K, texts as T

log = logging.getLogger("rename")
router = Router(name="rename")


class HasDialog(Filter):
    def __init__(self, kind: str):
        self.kind = kind

    async def __call__(self, message: Message, ctx) -> bool:
        return bool(message.from_user and ctx.dialogs.get(message.from_user.id, self.kind))


def link_or_copy(src: Path, dst: Path):
    """hardlink فوري (نفس الديسك)، ولو مش ممكن نسخ عادي."""
    try:
        os.link(src, dst)
    except OSError:
        shutil.copyfile(src, dst)


async def show_rename_prompt(bot: Bot, ctx, uid: int, ref: str, chat_id: int, msg_id: int, ext_mode: str = "keep"):
    sess = ctx.runtime.get_session(ref, uid)
    if not sess:
        return await edit_safe(bot, chat_id, msg_id, "⏰ الكارت انتهت صلاحيته — ابعت الملف تاني 📎", None)
    name = sess["name"]
    _stem, ext = split_ext(name)
    smart = smart_name(name)
    ctx.dialogs.set(uid, Dialog("rename", ref, chat_id, msg_id, time.time() + Dialogs.TIMEOUT, {"ext_mode": ext_mode}))
    await edit_safe(bot, chat_id, msg_id, T.rename_prompt(name, smart or "", ext_mode, ext),
                    K.rename_prompt(ref, smart, ext_mode, ext))


@router.callback_query(F.data.startswith("c:rename:"))
async def cb_rename(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if await need_session(cb, ctx, ref):
        await show_rename_prompt(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
        await cb.answer()


@router.callback_query(F.data.startswith("r:ext:"))
async def cb_ext(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if not await need_session(cb, ctx, ref):
        return
    dlg = ctx.dialogs.get(cb.from_user.id, "rename")
    mode = "custom" if (dlg and dlg.data.get("ext_mode") == "keep") else "keep"
    await show_rename_prompt(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id, mode)
    await cb.answer("الامتداد: " + ("ثابت" if mode == "keep" else "هتكتبه بنفسك"))


@router.callback_query(F.data.startswith("r:smart:"))
async def cb_smart(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    sess = await need_session(cb, ctx, ref)
    if not sess:
        return
    smart = smart_name(sess["name"])
    if not smart:
        return await cb.answer("مفيش اقتراح أحسن من الاسم الحالي 🙂", show_alert=True)
    await cb.answer()
    await start_rename(bot, ctx, cb.from_user.id, ref, build_final_name(smart, sess["name"], "keep"),
                       cb.message.chat.id, cb.message.message_id)


@router.message(F.text, ~F.text.startswith("/"), ~F.text.in_(K.MAIN_LABELS), HasDialog("rename"))
async def on_new_name(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid, "rename")
    sess = ctx.runtime.get_session(dlg.ref, uid)
    if not sess:
        ctx.dialogs.clear(uid)
        return await msg.reply("⏰ الكارت انتهت صلاحيته — ابعت الملف تاني 📎")
    final = build_final_name(msg.text, sess["name"], dlg.data.get("ext_mode", "keep"))
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    if not final:
        return await msg.answer("⚠️ الاسم ده مش صالح (فاضي أو رموز ممنوعة). اكتب اسم تاني 👇")
    if final == sess["name"]:
        return await msg.answer("🙂 ده نفس الاسم الحالي. اكتب اسم مختلف 👇")
    await start_rename(bot, ctx, uid, dlg.ref, final, dlg.chat_id, dlg.msg_id)


async def start_rename(bot: Bot, ctx, uid: int, ref: str, final_name: str, chat_id: int, msg_id: int):
    ctx.dialogs.clear(uid)
    sess = ctx.runtime.get_session(ref, uid)
    if not sess:
        return await edit_safe(bot, chat_id, msg_id, "⏰ الكارت انتهت صلاحيته — ابعت الملف تاني 📎", None)
    old_name = sess["name"]
    settings = ctx.store.all_settings(uid)

    async def run(job: Job):
        s = ctx.runtime.get_session(ref, uid)
        if not s:
            raise UserError("الكارت انتهت صلاحيته — ابعت الملف تاني 📎")
        src = Path(s["local"])
        if not src.is_file():
            raise UserError("الملف اتمسح من السيرفر (تنظيف تلقائي للمساحة) — ابعته تاني وهتلاقيه بيتحمّل بسرعة.")
        jobdir = ctx.cfg.jobs_dir / job.id
        jobdir.mkdir(parents=True, exist_ok=True)
        job.add_cleanup(lambda: shutil.rmtree(jobdir, ignore_errors=True))
        dst = jobdir / final_name

        rep = Reporter(bot, chat_id, msg_id, markup=K.job_controls(job.id))
        t0 = time.monotonic()
        await rep.update(f"🔗 <b>{job.title}</b>\nبجهّز الملف بالاسم الجديد…", force=True)
        await asyncio.to_thread(link_or_copy, src, dst)

        prefer = ctx.store.kv_get("send_mode")
        size = dst.stat().st_size

        def render(el):
            return (f"⬆️ <b>{job.title}</b>\nجاري الرفع لتليجرام ({human_size(size)})…\n⏱ {human_elapsed(el)}\n"
                    f"<i>الملفات الكبيرة بتاخد دقايق — مفيش progress حقيقي من السيرفر.</i>")

        async with ticker(rep, render, interval=4.0):
            mode = await send_file(bot, chat_id, dst, s["kind"], s.get("probe", {}), settings, prefer)
        if mode != prefer:
            ctx.store.kv_set("send_mode", mode)

        ctx.runtime.update_session(ref, name=final_name)
        await rep.update(
            f"✅ <b>تمت إعادة التسمية</b>\n<s>{esc(old_name)}</s>\n⬇️\n<code>{esc(final_name)}</code>\n"
            f"📦 {human_size(size)} • ⏱ {human_elapsed(time.monotonic() - t0)}",
            K.after_job(ref), force=True)

    job = Job(user_id=uid, chat_id=chat_id, msg_id=msg_id, title="إعادة تسمية", run=run)
    pos = await ctx.queue.submit(job)
    if pos == 0:
        await edit_safe(bot, chat_id, msg_id, "🔗 <b>إعادة تسمية</b>\nبدأت…", K.job_controls(job.id))


@router.callback_query(F.data.startswith("j:cancel:"))
async def cb_cancel(cb: CallbackQuery, bot: Bot, ctx):
    jid = cb.data.split(":", 2)[2]
    job = ctx.queue.jobs.get(jid)
    was_queued = bool(job and job.state == "queued")
    if ctx.queue.cancel(jid, cb.from_user.id):
        if was_queued:   # العامل مش هيعدّل رسالة المهام اللي اتلغت وهي مستنية
            await edit_safe(bot, job.chat_id, job.msg_id, f"🛑 <b>{job.title}</b> — اتلغت.", None)
        await cb.answer("اتلغت 🛑")
    else:
        await cb.answer("المهمة خلصت أو اتلغت بالفعل", show_alert=False)
