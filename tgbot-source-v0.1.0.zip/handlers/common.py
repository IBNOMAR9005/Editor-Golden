from __future__ import annotations

import logging
import shutil
from pathlib import Path

from aiogram.types import CallbackQuery, Message

log = logging.getLogger("handlers")


async def safe_delete(msg: Message | None):
    if msg is None:
        return
    try:
        await msg.delete()
    except Exception:
        pass


async def need_session(cb: CallbackQuery, ctx, ref: str):
    """بيرجّع الجلسة أو بيعرض تنبيه مفهوم لو الكارت انتهت صلاحيته."""
    sess = ctx.runtime.get_session(ref, cb.from_user.id)
    if not sess:
        await cb.answer("⏰ الكارت ده انتهت صلاحيته — ابعت الملف تاني 📎", show_alert=True)
    return sess


def drop_session_files(ctx, ref: str):
    """بيمسح ملف الجلسة المحلي (لو جوه مجلدات البوت بس) ويحذف الجلسة."""
    sess = ctx.runtime.get_session(ref, touch=False)
    if sess and sess.get("local"):
        p = Path(sess["local"])
        try:
            rp = p.resolve()
            if any(rp.is_relative_to(Path(r).resolve()) for r in (ctx.cfg.server_dir, ctx.cfg.server_tmp)):
                p.unlink(missing_ok=True)
        except Exception:
            log.debug("could not remove session file")
    ctx.runtime.drop_session(ref)
