"""تنظيف مؤقتات: كروت الملفات المنتهية + ملفات السيرفر المحلي (--dir) + مجلدات المهام اليتيمة.
ديسك Colab محدود فالتنظيف دوري وبيتشدد لو المساحة قلّت."""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import time
from pathlib import Path

from core.utils import disk_free

log = logging.getLogger("cleanup")
LOW_DISK = 4 * 1024 ** 3  # تحت 4GB = تنظيف أشد


def _inside(path: Path, roots) -> bool:
    try:
        rp = path.resolve()
        return any(rp.is_relative_to(Path(r).resolve()) for r in roots)
    except Exception:
        return False


def _rm(path: Path):
    try:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)
    except Exception:
        pass


def sweep_once(cfg, store, active_job_ids=()) -> int:
    """بيرجع عدد اللي اتمسح. آمن: مبيمسحش غير جوه مجلدات البوت."""
    removed = 0
    roots = (cfg.server_dir, cfg.server_tmp, cfg.jobs_dir)
    ttl = int(store.get_setting(0, "ttl_min") or 90) * 60
    low = disk_free(cfg.work) < LOW_DISK
    if low:
        ttl = min(ttl, 15 * 60)

    # 1) كروت منتهية: امسح ملفها المحلي واحذف الجلسة
    for ref, payload in store.expired_sessions(ttl):
        loc = payload.get("local")
        if loc and _inside(Path(loc), roots):
            _rm(Path(loc))
        store.drop_session(ref)
        removed += 1

    # 2) ملفات يتيمة في --dir مش تابعة لأي كارت حي وأقدم من TTL
    live = store.live_paths()
    now = time.time()
    for base in (cfg.server_dir, cfg.server_tmp):
        for root, _dirs, files in os.walk(base):
            for fn in files:
                p = Path(root) / fn
                try:
                    if str(p) in live or now - p.stat().st_mtime < max(ttl, 600):
                        continue
                except OSError:
                    continue
                if _inside(p, roots):
                    _rm(p)
                    removed += 1

    # 3) مجلدات مهام قديمة (فاضلة بعد crash)
    if cfg.jobs_dir.exists():
        for d in cfg.jobs_dir.iterdir():
            try:
                if d.name not in active_job_ids and now - d.stat().st_mtime > 1800:
                    _rm(d)
                    removed += 1
            except OSError:
                pass
    return removed


async def cleanup_loop(ctx, interval: int = 300):
    while True:
        await asyncio.sleep(interval)
        try:
            active = set(ctx.queue.jobs.keys())
            n = await asyncio.to_thread(sweep_once, ctx.cfg, ctx.runtime, active)
            if n:
                log.info("cleanup: removed %d item(s)", n)
        except Exception:
            log.exception("cleanup failed")
