"""الإقلاع: heartbeat على Drive، كشف الانقطاع، watchdog للسيرفر، ورسالة 'البوت اشتغل'."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from copy import deepcopy

from aiogram.exceptions import TelegramForbiddenError

from core import server
from core.progress import edit_safe  # noqa: F401  (متاح للاستخدام لاحقًا)
from ui import keyboards as K, texts as T

log = logging.getLogger("boot")


def _hb_path(cfg):
    return cfg.flags_dir / "heartbeat.json"


def read_hb(cfg):
    try:
        return json.loads(_hb_path(cfg).read_text())
    except Exception:
        return None


def write_hb(cfg, state: str, jobs=None):
    try:
        cfg.flags_dir.mkdir(parents=True, exist_ok=True)
        _hb_path(cfg).write_text(json.dumps({"ts": time.time(), "state": state, "jobs": jobs or []}))
    except Exception as e:
        log.debug("heartbeat write failed: %s", e)


def detect_boot(cfg) -> dict:
    hb = read_hb(cfg)
    if not hb:
        return {"boot_kind": "first"}
    gap = time.time() - float(hb.get("ts", 0))
    if hb.get("state") == "running":
        return {"boot_kind": "recovered", "gap_seconds": gap, "lost_jobs_raw": hb.get("jobs", [])}
    return {"boot_kind": "restart" if gap < 180 else "first", "gap_seconds": gap}


def current_jobs(ctx):
    return [{"uid": j.user_id, "title": j.title} for j in ctx.queue.jobs.values()
            if j.state in ("queued", "running")]


async def heartbeat_loop(ctx, interval: int = 30):
    while True:
        await asyncio.to_thread(write_hb, ctx.cfg, "running", current_jobs(ctx))
        await asyncio.sleep(interval)


async def notify_all(bot, ctx, text, markup=None, only_if=None):
    for uid in sorted(ctx.cfg.allowed):
        if only_if and not only_if(uid):
            continue
        try:
            await bot.send_message(uid, text, reply_markup=markup)
        except TelegramForbiddenError:
            log.warning("can't message %s yet — they need to press /start on the bot first", uid)
        except Exception as e:
            log.warning("notify %s failed: %s", uid, type(e).__name__)


async def announce_startup(bot, ctx):
    base = ctx.sysinfo()
    base.update({k: v for k, v in ctx.boot.items() if k != "lost_jobs_raw"})
    recovered = base.get("boot_kind") == "recovered"
    for uid in sorted(ctx.cfg.allowed):
        if not recovered and not ctx.store.get_setting(uid, "notify_boot"):
            continue
        info = deepcopy(base)
        info["lost_jobs"] = [j["title"] for j in ctx.boot.get("lost_jobs_raw", []) if j.get("uid") == uid]
        try:
            await bot.send_message(uid, T.startup(info), reply_markup=K.main_keyboard())
        except TelegramForbiddenError:
            log.warning("startup notice skipped for %s: they must open the bot and press /start once", uid)
        except Exception as e:
            log.warning("startup notice to %s failed: %s", uid, type(e).__name__)


async def watchdog_loop(bot, ctx, interval: int = 20):
    """بيراقب السيرفر المحلي ويرجّعه لو وقع، وبيبلّغ."""
    fails = 0
    while True:
        await asyncio.sleep(interval)
        alive = await asyncio.to_thread(server.is_alive, ctx.cfg, 8)
        if alive:
            if not ctx.server_ok:
                ctx.server_ok = True
            fails = 0
            continue
        fails += 1
        if fails < 2:      # مرة واحدة ممكن تكون تأخير مؤقت
            continue
        ctx.server_ok = False
        log.error("local Bot API server is down — restarting")
        ok = await asyncio.to_thread(server.ensure_running, ctx.cfg, 60)
        ctx.server_ok = ok
        if ok:
            fails = 0
            await notify_all(bot, ctx, "🛠 السيرفر المحلي كان واقف ورجّعته تلقائيًا. "
                                       "لو كانت فيه مهمة شغّالة ممكن تكون ضاعت — ابعتها تاني.")
        else:
            await notify_all(bot, ctx, "❌ السيرفر المحلي واقف ومقدرتش أرجّعه. شوف اللوج في الـ notebook.")
            fails = 0
            await asyncio.sleep(120)
