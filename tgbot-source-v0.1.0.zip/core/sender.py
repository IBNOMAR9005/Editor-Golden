"""إرسال ملف محلي لتليجرام عبر السيرفر المحلي. بنجرّب file:// الأول (من غير رفع زيادة)،
ولو السيرفر رفضه (مثلًا ترميز أسماء عربي) بنرجع لرفع multipart على localhost — والوضع اللي نجح بيتحفظ."""
from __future__ import annotations

import logging
from pathlib import Path

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import FSInputFile

log = logging.getLogger("sender")


async def send_file(bot: Bot, chat_id: int, path: Path, kind: str, probe: dict, settings: dict,
                    prefer: str | None = None) -> str:
    ext = path.suffix.lower()

    async def do(media):
        if kind == "audio" and settings.get("audio_as_player", True) and ext in (".mp3", ".m4a"):
            return await bot.send_audio(chat_id, audio=media, duration=int(probe.get("duration") or 0) or None,
                                        title=path.stem, performer=probe.get("artist") or None)
        if kind == "video" and ext == ".mp4":
            return await bot.send_video(chat_id, video=media, supports_streaming=True,
                                        duration=int(probe.get("duration") or 0) or None,
                                        width=probe.get("width"), height=probe.get("height"))
        return await bot.send_document(chat_id, document=media, disable_content_type_detection=True)

    if prefer != "upload":
        try:
            await do(path.as_uri())
            return "uri"
        except TelegramBadRequest as e:
            log.info("file:// rejected (%s) — falling back to multipart upload", str(e)[:80])
    await do(FSInputFile(path, filename=path.name))
    return "upload"
