"""تحميل assets من GitHub Releases مع التحقق من checksum. (نسخة مصغّرة منه موجودة جوه الـ notebook
عشان تحميل bot.zip نفسه بيحصل قبل ما المشروع يتفك.)"""
from __future__ import annotations

import hashlib
import json
import os
import urllib.request
from pathlib import Path

UA = {"User-Agent": "tgbot-colab"}


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_sha_file(text: str) -> str:
    return text.strip().split()[0].lower() if text.strip() else ""


def _open(url, token=None, accept=None):
    headers = dict(UA)
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if accept:
        headers["Accept"] = accept
    return urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=120)


def fetch_asset(repo: str, tag: str, name: str, dest, token: str | None = None) -> Path:
    """tag='latest' أو اسم tag. ريبو public من غير token، أو private بـ token."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    if token:
        rel_url = (f"https://api.github.com/repos/{repo}/releases/latest" if tag == "latest"
                   else f"https://api.github.com/repos/{repo}/releases/tags/{tag}")
        with _open(rel_url, token, "application/vnd.github+json") as r:
            rel = json.load(r)
        asset = next((a for a in rel.get("assets", []) if a["name"] == name), None)
        if not asset:
            raise FileNotFoundError(f"الـ asset «{name}» مش موجود في الـ Release")
        resp = _open(asset["url"], token, "application/octet-stream")
    else:
        url = (f"https://github.com/{repo}/releases/latest/download/{name}" if tag == "latest"
               else f"https://github.com/{repo}/releases/download/{tag}/{name}")
        resp = _open(url)
    with resp, open(tmp, "wb") as f:
        while True:
            chunk = resp.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
    os.replace(tmp, dest)
    return dest


def fetch_verified(repo, tag, name, dest, token=None) -> Path:
    """بينزّل الملف + name.sha256 وبيتحقق. بيرمي ValueError لو الـ checksum مش مطابق."""
    dest = fetch_asset(repo, tag, name, dest, token)
    sha_path = Path(str(dest) + ".sha256")
    fetch_asset(repo, tag, name + ".sha256", sha_path, token)
    expected = parse_sha_file(sha_path.read_text())
    actual = sha256_file(dest)
    if expected != actual:
        dest.unlink(missing_ok=True)
        raise ValueError(f"checksum مش مطابق لـ {name} (المتوقع {expected[:12]}… الفعلي {actual[:12]}…)")
    return dest
