"""قراءة الإعدادات والأسرار والتحقق منها. الأسرار بتيجي من متغيرات البيئة بس
(الـ notebook بيحطها من Colab Secrets) ومبتتكتبش في أي ملف ولا بتتطبع."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path


class ConfigError(Exception):
    """رسالة الخطأ هنا موجّهة للمستخدم (عربي + الحل)."""


TOKEN_RE = re.compile(r"^\d{6,12}:[A-Za-z0-9_-]{30,}$")
HASH_RE = re.compile(r"^[0-9a-fA-F]{32}$")


@dataclass(frozen=True)
class Config:
    bot_token: str
    api_id: int
    api_hash: str
    allowed: frozenset
    yt_cookies: str
    home: Path   # مكان دايم (Drive لو متوصّل)
    work: Path   # ديسك Colab المحلي السريع
    port: int = 8081

    # ---- مسارات ----
    @property
    def server_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def server_dir(self) -> Path:
        return self.work / "server-data"

    @property
    def server_tmp(self) -> Path:
        return self.work / "server-tmp"

    @property
    def jobs_dir(self) -> Path:
        return self.work / "jobs"

    @property
    def logs_dir(self) -> Path:
        return self.work / "logs"

    @property
    def bin_dir(self) -> Path:
        return self.work / "bin"

    @property
    def drive_bin(self) -> Path:
        return self.home / "bin"

    @property
    def flags_dir(self) -> Path:
        return self.home / "flags"

    @property
    def settings_db(self) -> Path:
        return self.home / "db" / "settings.sqlite"

    @property
    def runtime_db(self) -> Path:
        return self.work / "runtime.sqlite"

    @property
    def health_file(self) -> Path:
        return self.work / "health.json"

    @property
    def binary(self) -> Path:
        return self.bin_dir / "telegram-bot-api"

    def ensure_dirs(self) -> None:
        for p in (self.home, self.work, self.server_dir, self.server_tmp, self.jobs_dir,
                  self.logs_dir, self.bin_dir, self.flags_dir, self.settings_db.parent):
            p.mkdir(parents=True, exist_ok=True)

    def secret_values(self) -> list:
        vals = [self.bot_token, self.api_hash, self.yt_cookies]
        return [v for v in vals if v and len(v) >= 8]

    @classmethod
    def from_env(cls, env=None) -> "Config":
        env = os.environ if env is None else env
        problems = []

        token = (env.get("BOT_TOKEN") or "").strip()
        if not token:
            problems.append("❌ BOT_TOKEN ناقص — خده من @BotFather وحطه في Colab Secrets.")
        elif not TOKEN_RE.match(token):
            problems.append("❌ BOT_TOKEN شكله غلط (المفروض شكله 123456:ABC...). انسخه تاني من @BotFather من غير مسافات.")

        api_id_raw = (env.get("API_ID") or "").strip()
        api_id = 0
        if not api_id_raw:
            problems.append("❌ API_ID ناقص — من my.telegram.org ← API development tools.")
        elif not api_id_raw.isdigit():
            problems.append("❌ API_ID لازم يكون أرقام بس.")
        else:
            api_id = int(api_id_raw)

        api_hash = (env.get("API_HASH") or "").strip()
        if not api_hash:
            problems.append("❌ API_HASH ناقص — من نفس صفحة my.telegram.org.")
        elif not HASH_RE.match(api_hash):
            problems.append("❌ API_HASH شكله غلط (المفروض 32 حرف hex).")

        allowed_raw = (env.get("ALLOWED_USER_IDS") or "").strip()
        allowed = set()
        if not allowed_raw:
            problems.append("❌ ALLOWED_USER_IDS فاضي — البوت مش هيشتغل من غير whitelist عشان ما يتفتحش للكل بالغلط. "
                            "اعرف رقمك من @userinfobot أو شغّل البوت وابعت /id.")
        else:
            for part in re.split(r"[,\s]+", allowed_raw):
                if not part:
                    continue
                if not part.lstrip("-").isdigit():
                    problems.append(f"❌ ALLOWED_USER_IDS فيه قيمة مش رقم: «{part[:12]}». الشكل: 123456789,987654321")
                    break
                allowed.add(int(part))
            if not allowed and not any("ALLOWED_USER_IDS" in p for p in problems):
                problems.append("❌ ALLOWED_USER_IDS مفهوش أي رقم صالح.")

        if problems:
            raise ConfigError("\n".join(problems))

        home = Path(env.get("TGBOT_HOME") or "/content/drive/MyDrive/tgbot")
        work = Path(env.get("TGBOT_WORK") or "/content/tgwork")
        return cls(
            bot_token=token, api_id=api_id, api_hash=api_hash, allowed=frozenset(allowed),
            yt_cookies=(env.get("YT_COOKIES") or "").strip(), home=home, work=work,
            port=int(env.get("TGBOT_PORT") or 8081),
        )
