"""كل الأزرار. نظام الألوان (Bot API 9.4+ `style`):
   🟦 primary = الوظيفة الأساسية/المقترحة   🟩 success = ابدأ/تأكيد/مفعّل   🟥 danger = إلغاء/إغلاق/حذف
   بدون لون = خيارات ثانوية وتنقّل.
الأزرار الرئيسية = ReplyKeyboard دايمة وصلبة تحت الشات. الوظايف الفرعية = inline بنفس الألوان."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton as IB
from aiogram.types import InlineKeyboardMarkup, KeyboardButton as KB, ReplyKeyboardMarkup

from core import registry as R
from core.utils import split_ext

# ---------------- الأزرار الرئيسية (حقيقية، دايمة) ----------------
M_AUDIO, M_VIDEO, M_PDF = "🎵 صوت", "🎬 فيديو", "📄 PDF"
M_DL, M_RENAME, M_META = "⬇️ تحميل من رابط", "✏️ إعادة تسمية", "🏷️ Metadata"
M_STATUS, M_HELP, M_SETTINGS = "📊 الحالة", "❓ القدرات", "⚙️ إعدادات"
MAIN_LABELS = {M_AUDIO: "audio", M_VIDEO: "video", M_PDF: "pdf", M_DL: "link", M_RENAME: "rename",
               M_META: "meta", M_STATUS: "status", M_HELP: "help", M_SETTINGS: "settings"}


def main_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KB(text=M_AUDIO, style="primary"), KB(text=M_VIDEO, style="primary"), KB(text=M_PDF, style="primary")],
            [KB(text=M_DL, style="success"), KB(text=M_RENAME, style="success"), KB(text=M_META, style="success")],
            [KB(text=M_STATUS), KB(text=M_HELP), KB(text=M_SETTINGS)],
        ],
        resize_keyboard=True, is_persistent=True,
        input_field_placeholder="ابعت ملف أو رابط… أو اختار من تحت 👇",
    )


# ---------------- مساعدات inline ----------------
def b(text, data, style=None) -> IB:
    return IB(text=text, callback_data=data, **({"style": style} if style else {}))


def kb(*rows) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[list(r) for r in rows if r])


def _chunk(buttons, n=2):
    return [buttons[i:i + n] for i in range(0, len(buttons), n)]


# ---------------- كارت الملف ----------------
def file_card(ref: str, kind: str, name: str = "") -> InlineKeyboardMarkup:
    """الأزرار الجاهزة فعلًا لنوع الملف. الـ primary ياخد صف كامل فوق، والباقي 2-2."""
    acts = [a for a in R.for_kind(kind, True) if a.key not in ("info",)]
    primary = [a for a in acts if a.style == "primary"]
    others = [a for a in acts if a.style != "primary"]
    rows = [[b(a.label, f"c:{a.key}:{ref}", "primary")] for a in primary]
    rows += _chunk([b(a.label, f"c:{a.key}:{ref}", a.style or None) for a in others], 2)
    rows.append([b("📋 كل التفاصيل", f"c:info:{ref}"), b("🗑 إغلاق", f"c:close:{ref}", "danger")])
    return kb(*rows)


def details_view(ref: str) -> InlineKeyboardMarkup:
    return kb([b("↩️ رجوع للكارت", f"c:card:{ref}", "primary"), b("🗑 إغلاق", f"c:close:{ref}", "danger")])


# ---------------- إعادة التسمية ----------------
def rename_prompt(ref: str, smart: str | None, ext_mode: str, orig_ext: str) -> InlineKeyboardMarkup:
    rows = []
    if smart:
        label = smart if len(smart) <= 30 else smart[:29] + "…"
        rows.append([b(f"🪄 اسم ذكي: {label}", f"r:smart:{ref}", "success")])
    if orig_ext:
        keep = ext_mode == "keep"
        rows.append([b(f"🔤 الامتداد {orig_ext}: " + ("ثابت ✅" if keep else "هكتبه بنفسي ✏️"),
                       f"r:ext:{ref}", None)])
    rows.append([b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])
    return kb(*rows)


def after_job(ref: str) -> InlineKeyboardMarkup:
    return kb([b("📎 كارت الملف", f"c:card:{ref}", "primary"), b("✖️ إخفاء", "x:close", None)])


def job_controls(job_id: str, label: str = "⏹ إلغاء المهمة") -> InlineKeyboardMarkup:
    return kb([b(label, f"j:cancel:{job_id}", "danger")])


# ---------------- أقسام / حالة / إعدادات ----------------
def section_panel(section: str, show_help: bool = True) -> InlineKeyboardMarkup:
    rows = []
    if show_help:
        rows.append([b("❓ كل القدرات", "m:help", "primary"), b("📊 الحالة", "m:status")])
    rows.append([b("✖️ إخفاء", "x:close", "danger")])
    return kb(*rows)


def status_panel() -> InlineKeyboardMarkup:
    return kb([b("🔄 تحديث", "m:status", "primary"), b("❓ القدرات", "m:help")],
              [b("✖️ إخفاء", "x:close", "danger")])


def help_panel() -> InlineKeyboardMarkup:
    return kb([b("📊 الحالة", "m:status", "primary"), b("⚙️ إعدادات", "m:settings")],
              [b("✖️ إخفاء", "x:close", "danger")])


SETTING_LABELS = {
    "notify_boot": "🔔 إشعار عند تشغيل البوت",
    "clean_chat": "🧹 مسح رسايلي بعد قراءتها (شات نضيف)",
    "audio_as_player": "🎧 الصوت كـ Audio player",
}


def settings_panel(values: dict) -> InlineKeyboardMarkup:
    rows = []
    for key, label in SETTING_LABELS.items():
        on = bool(values.get(key))
        rows.append([b(("✅ " if on else "⬜ ") + label, f"s:tgl:{key}", "success" if on else None)])
    rows.append([b("✖️ إخفاء", "x:close", "danger")])
    return kb(*rows)
