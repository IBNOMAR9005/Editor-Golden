"""نصوص وأزرار الصوت. نفس لغة الألوان: أزرق=مقترح، أخضر=ابدأ/المختار، أحمر=إلغاء."""
from __future__ import annotations

from core.utils import esc, human_duration, human_size
from services import audio as A
from ui.keyboards import b, kb

BAR = "━━━━━━━━━━━━━━"
CH_LABEL = {"keep": "🔈 كما هي", "1": "1️⃣ مونو", "2": "2️⃣ ستيريو"}


def _chunk(xs, n):
    return [xs[i:i + n] for i in range(0, len(xs), n)]


def _src_line(name, probe):
    bits = []
    if probe.get("acodec"):
        bits.append(probe["acodec"])
    sk = A.source_kbps(probe)
    if sk:
        bits.append(f"{sk}kbps")
    if probe.get("duration"):
        bits.append(human_duration(probe["duration"]))
    return f"<code>{esc(name)}</code>" + (f"\n<i>{' • '.join(bits)}</i>" if bits else "")


# ---------------- تحويل ----------------
def convert_text(name, probe, op, reason):
    est = A.est_size(probe.get("duration"), op["fmt"], op.get("kbps"), op["ch"], probe.get("channels"))
    lines = ["🔁 <b>تحويل الصيغة</b>", BAR, _src_line(name, probe), "", f"💡 <b>مقترح:</b> {esc(reason)}", ""]
    chosen = f"<b>{A.FORMATS[op['fmt']]['ext'].lstrip('.').upper()}</b>"
    if op.get("kbps"):
        chosen += f" • {op['kbps']}kbps"
    chosen += f" • {CH_LABEL[op['ch']].split(' ', 1)[1]}"
    lines.append(f"✅ اختيارك: {chosen}")
    if est:
        lines.append(f"📦 الحجم المتوقع: ≈ {human_size(est)}")
    lines.append("\n<i>اختار الصيغة والجودة ثم ▶️ ابدأ.</i>")
    return "\n".join(lines)


def convert_kb(ref, op, sug_fmt, rates):
    fmts = []
    for f in A.ORDER:
        label = f.upper()
        if f == op["fmt"]:
            fmts.append(b("✅ " + label, f"a:fmt:{ref}:{f}", "success"))
        elif f == sug_fmt:
            fmts.append(b("⭐ " + label, f"a:fmt:{ref}:{f}", "primary"))
        else:
            fmts.append(b(label, f"a:fmt:{ref}:{f}"))
    rows = _chunk(fmts, 3)
    if rates:
        rows += _chunk([b(("✅ " if r == op.get("kbps") else "") + f"{r}k", f"a:br:{ref}:{r}",
                          "success" if r == op.get("kbps") else None) for r in rates], 3)
    rows.append([b(("✅ " if k == op["ch"] else "") + lab, f"a:ch:{ref}:{k}", "success" if k == op["ch"] else None)
                 for k, lab in CH_LABEL.items()])
    rows.append([b("▶️ ابدأ التحويل", f"a:go:{ref}", "success")])
    rows.append([b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])
    return kb(*rows)


# ---------------- قص ----------------
def cut_prompt(name, duration):
    return ("✂️ <b>قص جزء</b>\n" + BAR + f"\n<code>{esc(name)}</code>\n⏱ المدة: <b>{human_duration(duration)}</b>\n\n"
            "✍️ اكتب <b>البداية والنهاية</b>:\n• <code>01:20 03:45</code>\n• <code>80 225</code> (ثواني)\n"
            "• <code>01:20 -</code> (من 01:20 لحد النهاية)\n<i>⏳ عندك 5 دقايق.</i>")


def back_cancel(ref):
    return kb([b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])


# ---------------- تقسيم ----------------
def split_text(name, duration):
    return ("🔪 <b>تقسيم لأجزاء</b>\n" + BAR + f"\n<code>{esc(name)}</code>\n⏱ المدة: <b>{human_duration(duration)}</b>\n\n"
            "اختار عدد الأجزاء المتساوية، أو اكتب نقاط زمنية بنفسك.\n"
            "هتتسمّى <code>الاسم (part1)</code> و<code>(part2)</code>…")


def split_kb(ref, duration):
    ns = [n for n in (2, 3, 4, 5, 6, 8, 10) if duration / n >= 5]
    rows = _chunk([b(f"{n} أجزاء", f"a:sn:{ref}:{n}", "primary" if n == 2 else None) for n in ns], 4)
    rows.append([b("✍️ نقاط زمنية بنفسي", f"a:sp:{ref}")])
    rows.append([b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])
    return kb(*rows)


def points_prompt(duration):
    return ("✍️ اكتب <b>نقاط التقسيم</b> (كل نقطة هتقطع عندها):\n<code>05:00 12:30 20:00</code>\n"
            f"⏱ مدة الملف: {human_duration(duration)} — الحد الأقصى 20 جزء.")


# ---------------- دمج ----------------
def merge_text(items):
    lines = ["🧩 <b>دمج ريكوردات</b>", BAR, "📥 ابعت ملفات صوت تانية لإضافتها (لحد 10).\n<b>الترتيب الحالي:</b>"]
    total = 0
    for i, (n, d) in enumerate(items, 1):
        total += d or 0
        lines.append(f"{i}. <code>{esc(n)}</code> — {human_duration(d)}")
    lines.append(f"\n⏱ المجموع: {human_duration(total)}")
    if len(items) < 2:
        lines.append("<i>محتاج ملفين على الأقل.</i>")
    return "\n".join(lines)


def merge_kb(ref, n):
    rows = []
    for i in range(n):
        r = [b(f"{i + 1} 🔼", f"a:mv:{ref}:{i}:u") if i else b("·", "a:noop"),
             b(f"{i + 1} 🔽", f"a:mv:{ref}:{i}:d") if i < n - 1 else b("·", "a:noop")]
        if n > 1:
            r.append(b(f"❌ {i + 1}", f"a:mrm:{ref}:{i}"))
        rows.append(r)
    rows.append([b(f"✅ ادمج الآن ({n})", f"a:mgo:{ref}", "success" if n >= 2 else None)])
    rows.append([b("✖️ إلغاء", f"c:close:{ref}", "danger")])
    return kb(*rows)


# ---------------- تنقية ----------------
def denoise_text(name, probe):
    return ("🎙 <b>تنقية الصوت</b>\n" + BAR + "\n" + _src_line(name, probe) + "\n\n"
            "⚡ <b>سريع (FFmpeg):</b> فلتر ضوضاء + قطع الرمبلة المنخفضة. ثواني، وكفاية لمعظم الريكوردات.\n"
            "🤖 <b>ذكي (AI):</b> DeepFilterNet — أنضف في الأصوات الصعبة، بس بينزّل مكتبة تقيلة أول مرة وممكن ما يشتغلش على كل بيئة "
            "(<b>تجريبي</b>).")


def denoise_kb(ref):
    return kb([b("⚡ سريع (FFmpeg)", f"a:dn:{ref}:fast", "primary")],
              [b("🤖 ذكي AI (تجريبي)", f"a:dn:{ref}:ai")],
              [b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])


# ---------------- اسم الناتج ----------------
def name_prompt(default, extra=""):
    return ("✍️ <b>اسم الملف الناتج</b>\n" + (extra + "\n" if extra else "") +
            f"الافتراضي:\n<code>{esc(default)}</code>\n\nاكتب اسم تاني أو اضغط تخطي.")


def name_kb(ref):
    return kb([b("⏭ تخطي — الاسم الافتراضي", f"a:skip:{ref}", "success")],
              [b("↩️ رجوع", f"c:card:{ref}"), b("✖️ إلغاء", f"c:close:{ref}", "danger")])
