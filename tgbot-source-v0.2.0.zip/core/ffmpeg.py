"""تشغيل ffmpeg مع progress حقيقي (-progress pipe:1) وإلغاء يقتل العملية."""
from __future__ import annotations

import asyncio
import re
from typing import Awaitable, Callable

from core.queue import Job

_TIME = re.compile(r"out_time_(?:us|ms)=(\d+)")


async def run_ffmpeg(job: Job, args, duration: float | None = None,
                     on_progress: Callable[[float], Awaitable[None]] | None = None):
    """بيرجّع (returncode, آخر stderr). duration = مدة الناتج المتوقعة (لحساب النسبة)."""
    cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-y", "-loglevel", "error", "-progress", "pipe:1", "-nostats",
           *map(str, args)]
    proc = await asyncio.create_subprocess_exec(*cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    job.procs.add(proc)
    err_task = asyncio.create_task(proc.stderr.read())
    try:
        while True:
            raw = await proc.stdout.readline()
            if not raw:
                break
            m = _TIME.match(raw.decode("utf-8", "ignore").strip())
            if m and duration and on_progress:
                await on_progress(min(99.0, int(m.group(1)) / 1e6 / duration * 100))
        rc = await proc.wait()
    finally:
        job.procs.discard(proc)
        if proc.returncode is None:
            proc.kill()
    err = (await err_task).decode("utf-8", "ignore").strip()
    return rc, err[-400:]


def short_error(err: str) -> str:
    """سطر خطأ مفهوم من غير مسارات."""
    last = (err.strip().splitlines() or ["خطأ غير معروف"])[-1]
    return re.sub(r"/[^\s:]+/", "", last)[:160]
