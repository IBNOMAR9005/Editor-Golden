"""منطق الصوت (بدون تليجرام): بناء أوامر ffmpeg، تحليل الأوقات، اقتراحات ذكية، أسماء افتراضية."""
from __future__ import annotations

import re

from core.utils import human_duration, sanitize_filename, split_ext

FORMATS = {
    "mp3": {"ext": ".mp3", "codec": ["-c:a", "libmp3lame"], "lossy": True, "rates": [64, 96, 128, 192, 256, 320]},
    "m4a": {"ext": ".m4a", "codec": ["-c:a", "aac"], "lossy": True, "rates": [64, 96, 128, 192, 256]},
    "opus": {"ext": ".opus", "codec": ["-c:a", "libopus"], "lossy": True, "rates": [24, 32, 48, 64, 96, 128]},
    "ogg": {"ext": ".ogg", "codec": ["-c:a", "libvorbis"], "lossy": True, "rates": [64, 96, 128, 192, 256]},
    "wav": {"ext": ".wav", "codec": ["-c:a", "pcm_s16le"], "lossy": False, "rates": []},
    "flac": {"ext": ".flac", "codec": ["-c:a", "flac"], "lossy": False, "rates": []},
}
ORDER = ["mp3", "m4a", "opus", "ogg", "wav", "flac"]
BASE_KBPS = {"mp3": 192, "m4a": 128, "opus": 64, "ogg": 128}
EXT_TO_FMT = {".mp3": "mp3", ".m4a": "m4a", ".aac": "m4a", ".ogg": "ogg", ".oga": "ogg", ".opus": "opus",
              ".wav": "wav", ".flac": "flac"}
TITLES = {"convert": "تحويل الصيغة", "cut": "قص جزء", "split": "تقسيم", "merge": "دمج", "denoise": "تنقية الصوت"}


# ---------------- بيانات المصدر والاقتراحات ----------------
def source_kbps(probe: dict):
    v = probe.get("audio_bitrate") or probe.get("bitrate")
    return int(v) // 1000 if v else None


def allowed_rates(fmt: str, src_kbps) -> list:
    """مبنقترحش bitrate أعلى من الأصلي (ده بيكبّر الحجم من غير جودة أحسن)."""
    rates = FORMATS[fmt]["rates"]
    if not rates or not src_kbps:
        return list(rates)
    ok = [r for r in rates if r <= src_kbps * 1.05]
    return ok or [rates[0]]


def default_kbps(fmt: str, src_kbps, prefer=None):
    rates = allowed_rates(fmt, src_kbps)
    if not rates:
        return None
    if prefer in rates:
        return prefer
    base = BASE_KBPS.get(fmt, 128)
    below = [r for r in rates if r <= base]
    return below[-1] if below else rates[0]


def suggest(probe: dict, name: str):
    """(fmt, kbps, channels, سبب) — الاقتراح الأذكى للتحويل بناءً على الملف."""
    ext = split_ext(name)[1].lower()
    sk = source_kbps(probe)
    ch = probe.get("channels")
    if ext in (".wav", ".flac", ".aiff"):
        return "mp3", default_kbps("mp3", None, 192), "keep", "الأصل بدون ضغط — MP3 192k أصغر بكتير وتمام للمشاركة"
    if ext == ".mp3" and sk and sk >= 256:
        return "mp3", 128, "keep", f"الـ bitrate الأصلي {sk}k عالي — 128k هيصغّر الحجم للنص تقريبًا"
    if ext in (".ogg", ".opus", ".oga"):
        return "mp3", default_kbps("mp3", sk, 128), "keep", "MP3 بيشتغل على كل الأجهزة والمشغّلات"
    if ch == 1:
        return "opus", default_kbps("opus", sk, 48), "keep", "الصوت مونو (غالبًا كلام) — OPUS أفضل جودة بأصغر حجم"
    return "mp3", default_kbps("mp3", sk, 192), "keep", "أنسب صيغة متوافقة مع كل حاجة"


def est_size(duration, fmt: str, kbps, channels="keep", probe_ch=2) -> int | None:
    if not duration:
        return None
    if FORMATS[fmt]["lossy"] and kbps:
        return int(duration * kbps * 1000 / 8)
    ch = 1 if channels == "1" else 2 if channels == "2" else (probe_ch or 2)
    wav = duration * 44100 * 2 * ch
    return int(wav if fmt == "wav" else wav * 0.6)


def fmt_from_name(name: str) -> str:
    return EXT_TO_FMT.get(split_ext(name)[1].lower(), "mp3")


# ---------------- أوامر ffmpeg ----------------
def convert_args(src, dst, fmt, kbps, ch="keep"):
    a = ["-i", src, "-vn", "-map_metadata", "0", *FORMATS[fmt]["codec"]]
    if FORMATS[fmt]["lossy"] and kbps:
        a += ["-b:a", f"{kbps}k"]
    if ch in ("1", "2"):
        a += ["-ac", ch]
    return a + [dst]


def cut_args(src, dst, start, end, copy=True):
    a = ["-ss", f"{start:.3f}", "-i", src, "-t", f"{end - start:.3f}", "-vn", "-map_metadata", "0"]
    return a + (["-c", "copy"] if copy else []) + [dst]


def denoise_args(src, dst, src_kbps=None):
    fmt = fmt_from_name(str(dst))
    kb = min(256, max(96, src_kbps or 128))
    a = ["-i", src, "-vn", "-af", "highpass=f=80,afftdn=nr=15:nf=-45", "-map_metadata", "0", *FORMATS[fmt]["codec"]]
    if FORMATS[fmt]["lossy"]:
        a += ["-b:a", f"{kb}k"]
    return a + [dst]


def merge_copy_args(listfile, dst):
    return ["-f", "concat", "-safe", "0", "-i", listfile, "-vn", "-c", "copy", dst]


def merge_reencode_args(srcs, dst, kbps=192):
    n = len(srcs)
    inputs = [x for s in srcs for x in ("-i", s)]
    norm = ";".join(f"[{i}:a]aformat=sample_rates=44100:channel_layouts=stereo[a{i}]" for i in range(n))
    cat = "".join(f"[a{i}]" for i in range(n)) + f"concat=n={n}:v=0:a=1[out]"
    return inputs + ["-filter_complex", f"{norm};{cat}", "-map", "[out]", "-c:a", "libmp3lame", "-b:a", f"{kbps}k", dst]


def write_concat_list(paths, listfile):
    with open(listfile, "w", encoding="utf-8") as f:
        for p in paths:
            f.write("file '" + str(p).replace("'", "'\\''") + "'\n")


def can_copy_merge(probes: list, names: list) -> bool:
    keys = {(p.get("acodec"), p.get("sample_rate"), p.get("channels"), split_ext(n)[1].lower())
            for p, n in zip(probes, names)}
    return len(keys) == 1 and None not in next(iter(keys))[:3]


# ---------------- الأوقات ----------------
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_TOKEN = re.compile(r"\d+(?::\d{1,2}){0,2}(?:\.\d+)?")


def parse_time(tok: str):
    parts = tok.split(":")
    try:
        vals = [float(p) for p in parts]
    except ValueError:
        return None
    if len(vals) == 1:
        return vals[0]
    if len(vals) == 2:
        return vals[0] * 60 + vals[1]
    return vals[0] * 3600 + vals[1] * 60 + vals[2]


def parse_range(text: str, duration: float):
    """بيرجّع (start, end) أو رسالة خطأ (str). '01:20 03:45' أو '80 225' أو '01:20 -' (لحد النهاية)."""
    t = text.translate(_DIGITS)
    toks = _TOKEN.findall(t)
    if len(toks) == 1 and ("-" in t or "نهاية" in t or "آخر" in t):
        start, end = parse_time(toks[0]), duration
    elif len(toks) == 2:
        start, end = parse_time(toks[0]), parse_time(toks[1])
    else:
        return "اكتب وقتين: البداية والنهاية، مثال: <code>01:20 03:45</code> أو <code>80 225</code> (ثواني)."
    if start is None or end is None:
        return "الوقت مش مفهوم."
    if start >= duration:
        return f"البداية بعد نهاية الملف (مدته {human_duration(duration)})."
    end = min(end, duration)
    if end - start < 0.5:
        return "المقطع قصير جدًا — لازم النهاية تبقى بعد البداية بنص ثانية على الأقل."
    return start, end


def parse_points(text: str, duration: float):
    toks = _TOKEN.findall(text.translate(_DIGITS))
    pts = sorted({round(parse_time(t), 3) for t in toks if parse_time(t) is not None})
    if not pts:
        return "اكتب نقاط التقسيم، مثال: <code>05:00 12:30 20:00</code>."
    bad = [p for p in pts if p <= 0.5 or p >= duration - 0.5]
    if bad:
        return f"فيه نقطة برا مدة الملف ({human_duration(duration)}) أو قريبة جدًا من الأطراف."
    if len(pts) > 19:
        return "الحد الأقصى 20 جزء (19 نقطة)."
    return pts


def equal_points(duration: float, n: int):
    return [round(duration * i / n, 3) for i in range(1, n)]


def segments(points, duration):
    edges = [0.0, *points, duration]
    return list(zip(edges[:-1], edges[1:]))


def tag_time(sec: float) -> str:
    sec = int(sec)
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m{s:02d}s" if h else f"{m:02d}m{s:02d}s"


# ---------------- الأسماء ----------------
def default_name(stem: str, op: dict, ext: str, src_ext: str = "") -> str:
    t = op["type"]
    if t == "convert":
        return stem if ext != src_ext else f"{stem} ({op.get('kbps') or 'conv'}k)"
    if t == "cut":
        return f"{stem} (cut {tag_time(op['start'])}-{tag_time(op['end'])})"
    if t == "denoise":
        return f"{stem} (clean)"
    if t == "merge":
        return f"{stem} (merged {len(op['refs'])})"
    return stem


def final_name(base: str, ext: str) -> str:
    """base ممكن المستخدم يكتبه بامتداد أو من غيره."""
    base = sanitize_filename(base, fallback="audio")
    stem, e = split_ext(base)
    if e.lower() in (ext.lower(), ".mp3", ".m4a", ".ogg", ".opus", ".wav", ".flac"):
        base = stem
    return sanitize_filename(base + ext)
