"""اختبار عمليات الصوت بـ ffmpeg حقيقي وسيشن تليجرام مزيّف. تشغيل: python tests/audio_test.py"""
from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from smoke_test import *  # noqa: E402,F401,F403
from smoke_test import FakeSession, cb, msg, ROOT, OWNER, TOKEN  # noqa: E402,F811
from urllib.parse import unquote, urlparse  # noqa: E402

from handlers import audio  # noqa: E402


class CaptureSession(FakeSession):
    """بيلتقط الملفات اللي اتبعتت (file://) علشان نفحصها بـ ffprobe بعد ما المهمة تنضّف مجلدها."""
    def __init__(self, f, cap):
        super().__init__(f)
        self.cap, self.n = cap, 0

    async def make_request(self, bot, method, timeout=None):
        name = type(method).__name__
        media = getattr(method, "audio", None) or getattr(method, "document", None)
        if name in ("SendAudio", "SendDocument") and isinstance(media, str) and media.startswith("file://"):
            self.n += 1
            src = Path(unquote(urlparse(media).path))
            shutil.copy(src, self.cap / f"{self.n:02d}_{src.name}")
        return await super().make_request(bot, method, timeout)


def info(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
                       capture_output=True, text=True)
    d = json.loads(r.stdout)
    a = next(s for s in d["streams"] if s["codec_type"] == "audio")
    return a["codec_name"], float(d["format"]["duration"]), a.get("channels")


async def main():
    tmp = Path(tempfile.mkdtemp(prefix="tgaudio_"))
    cap = tmp / "cap"; cap.mkdir()
    env = {"BOT_TOKEN": TOKEN, "API_ID": "1", "API_HASH": "a" * 32, "ALLOWED_USER_IDS": str(OWNER),
           "TGBOT_HOME": str(tmp / "home"), "TGBOT_WORK": str(tmp / "work")}
    cfg = Config.from_env(env); cfg.ensure_dirs()
    d = cfg.server_dir / "documents"; d.mkdir(parents=True, exist_ok=True)
    wav, mp3a, mp3b = d / "a.wav", d / "b.mp3", d / "c.mp3"
    for f, dur, hz in ((wav, 20, 440), (mp3a, 6, 330), (mp3b, 4, 550)):
        subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-f", "lavfi", "-i", f"sine=frequency={hz}:duration={dur}", "-ac", "2", str(f)], check=True)

    sess = CaptureSession(wav, cap)
    bot = Bot(TOKEN, session=sess)
    ctx = AppCtx(cfg=cfg, store=Store(cfg.settings_db), runtime=Store(cfg.runtime_db),
                 queue=JobQueue(bot, cancel_markup=lambda j: K.job_controls(j.id)), dialogs=Dialogs(), version="0.2.0")
    dp = Dispatcher(ctx=ctx)
    wl = Whitelist(cfg.allowed); dp.message.outer_middleware(wl); dp.callback_query.outer_middleware(wl)
    for r in (start.router, menu.router, settings.router, file_router.router, rename.router, audio.router, fallback.router):
        dp.include_router(r)
    worker = asyncio.create_task(ctx.queue.worker())
    res = []
    ok = lambda c, label: print(("✅" if c else "❌"), label) or res.append(bool(c))  # noqa: E731
    mid = [100]

    def nid():
        mid[0] += 1
        return mid[0]

    async def send_file(path, name):
        sess.local_file = path
        doc = Document(file_id="F", file_unique_id="U", file_name=name, mime_type="audio/x-wav" if name.endswith("wav") else "audio/mpeg",
                       file_size=path.stat().st_size)
        await dp.feed_update(bot, msg(mid=nid(), document=doc))
        return ctx.runtime._exec("SELECT ref FROM sessions ORDER BY created DESC").fetchone()[0]

    async def settle():
        for _ in range(300):
            await asyncio.sleep(0.1)
            if ctx.queue.running is None and not ctx.queue._pending:
                await asyncio.sleep(0.2)
                break

    def last_edit():
        return [m for n, m in sess.calls if n == "EditMessageText"][-1]

    # ---- تحويل wav → opus مونو ----
    ref = await send_file(wav, "a.wav")
    await dp.feed_update(bot, cb(f"c:a_convert:{ref}", mid=nid()))
    t = last_edit().text
    ok("تحويل الصيغة" in t and "مقترح" in t, "لوحة التحويل + اقتراح ذكي (wav → mp3 192k)")
    await dp.feed_update(bot, cb(f"a:fmt:{ref}:opus", mid=nid()))
    await dp.feed_update(bot, cb(f"a:ch:{ref}:1", mid=nid()))
    await dp.feed_update(bot, cb(f"a:go:{ref}", mid=nid()))
    ok("اسم الملف الناتج" in last_edit().text, "بعد ابدأ: يسأل عن الاسم")
    await dp.feed_update(bot, msg("تسجيل جديد", mid=nid()))
    await settle()
    outs = sorted(cap.iterdir())
    c, dur, ch = info(outs[-1])
    ok(outs[-1].suffix == ".opus" and c == "opus" and ch == 1 and abs(dur - 20) < 1, f"التحويل: {outs[-1].name} codec={c} ch={ch} dur={dur:.1f}")
    ok("تحويل الصيغة تم" in last_edit().text, "رسالة النجاح")

    # ---- قص بتخطي الاسم ----
    n0 = len(list(cap.iterdir()))
    await dp.feed_update(bot, cb(f"c:a_cut:{ref}", mid=nid()))
    await dp.feed_update(bot, msg("بلا بلا", mid=nid()))
    ok("⚠️" in last_text(sess), "إدخال وقت غلط → رسالة خطأ والحوار مفتوح")
    await dp.feed_update(bot, msg("00:05 00:12", mid=nid()))
    await dp.feed_update(bot, cb(f"a:skip:{ref}", mid=nid()))
    await settle()
    new = sorted(cap.iterdir())[n0:]
    c, dur, _ = info(new[-1]) if new else (None, 0, 0)
    ok(new and abs(dur - 7) < 0.6 and "cut" in new[-1].name, f"القص 7 ثواني (اسم افتراضي): {new[-1].name if new else None} dur={dur:.1f}")

    # ---- تقسيم 4 أجزاء ----
    n0 = len(list(cap.iterdir()))
    await dp.feed_update(bot, cb(f"c:a_split:{ref}", mid=nid()))
    await dp.feed_update(bot, cb(f"a:sn:{ref}:4", mid=nid()))
    await dp.feed_update(bot, msg("محاضرة", mid=nid()))
    await settle()
    parts = sorted(cap.iterdir())[n0:]
    total = sum(info(p)[1] for p in parts)
    ok(len(parts) == 4 and all("(part" in p.name for p in parts) and abs(total - 20) < 1.2, f"التقسيم: {len(parts)} أجزاء مجموعها {total:.1f}s — {parts[0].name}")

    # ---- دمج: wav الأصل + mp3 + mp3 (صيغ مختلفة → إعادة ترميز mp3) ----
    n0 = len(list(cap.iterdir()))
    await dp.feed_update(bot, cb(f"c:a_merge:{ref}", mid=nid()))
    await send_file(mp3a, "b.mp3")
    await send_file(mp3b, "c.mp3")
    dlg = ctx.dialogs.get(OWNER, "merge")
    ok(dlg and len(dlg.data["refs"]) == 3, "السلة استقبلت الملفين الإضافيين (من غير كروت جديدة)")
    await dp.feed_update(bot, cb(f"a:mv:{ref}:0:d", mid=nid()))
    ok(dlg.data["refs"][0] != ref and dlg.data["refs"][1] == ref, "إعادة الترتيب 🔽")
    await dp.feed_update(bot, cb(f"a:mgo:{ref}", mid=nid()))
    await dp.feed_update(bot, cb(f"a:skip:{ref}", mid=nid()))
    await settle()
    new = sorted(cap.iterdir())[n0:]
    c, dur, _ = info(new[-1]) if new else (None, 0, 0)
    ok(new and abs(dur - 30) < 1.2, f"الدمج المختلط: {new[-1].name if new else None} dur={dur:.1f} (متوقع ~30)")

    # ---- دمج بنسخ مباشر (نفس الصيغة) ----
    ra = await send_file(mp3a, "b.mp3")
    rb = await send_file(mp3a, "b2.mp3")
    n0 = len(list(cap.iterdir()))
    await dp.feed_update(bot, cb(f"c:a_merge:{ra}", mid=nid()))
    await send_file(mp3a, "b3.mp3")
    dlg = ctx.dialogs.get(OWNER, "merge")
    await dp.feed_update(bot, cb(f"a:mgo:{ra}", mid=nid()))
    ok(".mp3" in last_edit().text, "اسم الدمج بامتداد الأصل")
    await dp.feed_update(bot, cb(f"a:skip:{ra}", mid=nid()))
    await settle()
    new = sorted(cap.iterdir())[n0:]
    ok(new and abs(info(new[-1])[1] - 12) < 0.8, f"دمج بالنسخ: dur={info(new[-1])[1]:.1f}" if new else "دمج بالنسخ فشل")

    # ---- تنقية سريعة ----
    n0 = len(list(cap.iterdir()))
    await dp.feed_update(bot, cb(f"c:a_denoise:{ref}", mid=nid()))
    await dp.feed_update(bot, cb(f"a:dn:{ref}:fast", mid=nid()))
    await dp.feed_update(bot, cb(f"a:skip:{ref}", mid=nid()))
    await settle()
    new = sorted(cap.iterdir())[n0:]
    ok(new and "clean" in new[-1].name and abs(info(new[-1])[1] - 20) < 1, f"التنقية السريعة: {new[-1].name if new else None}")

    ok(not any((cfg.jobs_dir).iterdir()), "مجلدات المهام اتنضّفت")
    ok(sess.sent("SendAudio"), "mp3/m4a بيتبعتوا كـ Audio player")
    worker.cancel()
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"\n{sum(res)}/{len(res)} اختبار نجح")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
