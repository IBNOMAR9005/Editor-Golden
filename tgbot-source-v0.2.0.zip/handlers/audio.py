"""المرحلة 2 — الصوت: تحويل • قص • تقسيم • دمج • تنقية. كل عملية: اختيارات بأزرار ← اسم الناتج (أو تخطي) ← طابور بتقدم حقيقي."""
from __future__ import annotations

import asyncio
import logging
import shutil
import sys
import time
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, Message

from core.ffmpeg import run_ffmpeg, short_error
from core.probe import probe_file
from core.progress import Reporter, bar, edit_safe, ticker
from core.queue import Job, UserError, run_cmd
from core.sender import deliver
from core.state import Dialog
from core.utils import esc, human_elapsed, human_size, split_ext
from handlers.common import need_session, safe_delete
from handlers.rename import HasDialog
from services import audio as A
from ui import audio_ui as U, keyboards as K

log = logging.getLogger("audio")
router = Router(name="audio")
MAX_MERGE = 10
EXPIRED = "⏰ الكارت انتهت صلاحيته — ابعت الملف تاني 📎"


def _src_kbps(s):
    return A.source_kbps(s.get("probe", {}))


def _dialog(ctx, uid, kind, ref, chat_id, msg_id, minutes=5, **data):
    ctx.dialogs.set(uid, Dialog(kind, ref, chat_id, msg_id, time.time() + minutes * 60, dict(data)))


# =================================================== تحويل
async def render_convert(bot, ctx, uid, ref, chat_id, msg_id):
    s = ctx.runtime.get_session(ref, uid)
    if not s or not s.get("op"):
        return await edit_safe(bot, chat_id, msg_id, EXPIRED, None)
    op = s["op"]
    rates = A.allowed_rates(op["fmt"], _src_kbps(s))
    await edit_safe(bot, chat_id, msg_id, U.convert_text(s["name"], s.get("probe", {}), op, op.get("reason", "")),
                    U.convert_kb(ref, op, op.get("sug"), rates))


@router.callback_query(F.data.startswith("c:a_convert:"))
async def cb_convert(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    s = await need_session(cb, ctx, ref)
    if not s:
        return
    fmt, kbps, ch, reason = A.suggest(s.get("probe", {}), s["name"])
    ctx.runtime.update_session(ref, op={"type": "convert", "fmt": fmt, "kbps": kbps, "ch": ch, "sug": fmt, "reason": reason})
    await render_convert(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
    await cb.answer()


@router.callback_query(F.data.startswith("a:fmt:"))
async def cb_fmt(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, fmt = cb.data.split(":")
    s = await need_session(cb, ctx, ref)
    if not s or fmt not in A.FORMATS or not s.get("op"):
        return
    op = s["op"]
    op["fmt"], op["kbps"] = fmt, A.default_kbps(fmt, _src_kbps(s), op.get("kbps"))
    ctx.runtime.update_session(ref, op=op)
    await render_convert(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
    await cb.answer()


@router.callback_query(F.data.startswith("a:br:"))
async def cb_br(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, k = cb.data.split(":")
    s = await need_session(cb, ctx, ref)
    if not s or not s.get("op"):
        return
    op = s["op"]
    if int(k) in A.allowed_rates(op["fmt"], _src_kbps(s)):
        op["kbps"] = int(k)
        ctx.runtime.update_session(ref, op=op)
    await render_convert(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
    await cb.answer()


@router.callback_query(F.data.startswith("a:ch:"))
async def cb_ch(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, ch = cb.data.split(":")
    s = await need_session(cb, ctx, ref)
    if not s or ch not in ("keep", "1", "2") or not s.get("op"):
        return
    s["op"]["ch"] = ch
    ctx.runtime.update_session(ref, op=s["op"])
    await render_convert(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
    await cb.answer()


@router.callback_query(F.data.startswith("a:go:"))
async def cb_go(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if await need_session(cb, ctx, ref):
        await ask_name(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
        await cb.answer()


# =================================================== قص
@router.callback_query(F.data.startswith("c:a_cut:"))
async def cb_cut(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    s = await need_session(cb, ctx, ref)
    if not s:
        return
    dur = s.get("probe", {}).get("duration")
    if not dur:
        return await cb.answer("معرفتش أعرف مدة الملف — مش هقدر أقص.", show_alert=True)
    _dialog(ctx, cb.from_user.id, "a_cut", ref, cb.message.chat.id, cb.message.message_id)
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, U.cut_prompt(s["name"], dur), U.back_cancel(ref))
    await cb.answer()


@router.message(F.text, ~F.text.startswith("/"), ~F.text.in_(K.MAIN_LABELS), HasDialog("a_cut"))
async def on_cut_text(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid, "a_cut")
    s = ctx.runtime.get_session(dlg.ref, uid)
    if not s:
        return await msg.reply(EXPIRED)
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    r = A.parse_range(msg.text, s["probe"]["duration"])
    if isinstance(r, str):
        return await msg.answer("⚠️ " + r)
    ctx.runtime.update_session(dlg.ref, op={"type": "cut", "start": r[0], "end": r[1]})
    await ask_name(bot, ctx, uid, dlg.ref, dlg.chat_id, dlg.msg_id,
                   extra=f"✂️ من <b>{A.tag_time(r[0])}</b> إلى <b>{A.tag_time(r[1])}</b> ({A.tag_time(r[1] - r[0])})")


# =================================================== تقسيم
@router.callback_query(F.data.startswith("c:a_split:"))
async def cb_split(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    s = await need_session(cb, ctx, ref)
    if not s:
        return
    dur = s.get("probe", {}).get("duration")
    if not dur or dur < 10:
        return await cb.answer("الملف قصير أو معرفتش أعرف مدته.", show_alert=True)
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, U.split_text(s["name"], dur), U.split_kb(ref, dur))
    await cb.answer()


@router.callback_query(F.data.startswith("a:sn:"))
async def cb_split_n(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, n = cb.data.split(":")
    s = await need_session(cb, ctx, ref)
    if not s:
        return
    pts = A.equal_points(s["probe"]["duration"], int(n))
    ctx.runtime.update_session(ref, op={"type": "split", "points": pts})
    await ask_name(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id,
                   extra=f"🔪 هيتقسم لـ <b>{n}</b> أجزاء متساوية")
    await cb.answer()


@router.callback_query(F.data.startswith("a:sp:"))
async def cb_split_points(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    s = await need_session(cb, ctx, ref)
    if s:
        _dialog(ctx, cb.from_user.id, "a_split", ref, cb.message.chat.id, cb.message.message_id)
        await edit_safe(bot, cb.message.chat.id, cb.message.message_id, U.points_prompt(s["probe"]["duration"]),
                        U.back_cancel(ref))
        await cb.answer()


@router.message(F.text, ~F.text.startswith("/"), ~F.text.in_(K.MAIN_LABELS), HasDialog("a_split"))
async def on_split_text(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid, "a_split")
    s = ctx.runtime.get_session(dlg.ref, uid)
    if not s:
        return await msg.reply(EXPIRED)
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    r = A.parse_points(msg.text, s["probe"]["duration"])
    if isinstance(r, str):
        return await msg.answer("⚠️ " + r)
    ctx.runtime.update_session(dlg.ref, op={"type": "split", "points": r})
    await ask_name(bot, ctx, uid, dlg.ref, dlg.chat_id, dlg.msg_id, extra=f"🔪 هيتقسم لـ <b>{len(r) + 1}</b> أجزاء")


# =================================================== تنقية
@router.callback_query(F.data.startswith("c:a_denoise:"))
async def cb_denoise(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    s = await need_session(cb, ctx, ref)
    if s:
        await edit_safe(bot, cb.message.chat.id, cb.message.message_id, U.denoise_text(s["name"], s.get("probe", {})),
                        U.denoise_kb(ref))
        await cb.answer()


@router.callback_query(F.data.startswith("a:dn:"))
async def cb_denoise_mode(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, mode = cb.data.split(":")
    if await need_session(cb, ctx, ref) and mode in ("fast", "ai"):
        ctx.runtime.update_session(ref, op={"type": "denoise", "mode": mode})
        await ask_name(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id,
                       extra="🎙 " + ("⚡ سريع (FFmpeg)" if mode == "fast" else "🤖 ذكي (DeepFilterNet — تجريبي)"))
        await cb.answer()


# =================================================== دمج (سلة ملفات)
def _basket_items(ctx, uid, refs):
    out = []
    for r in refs:
        s = ctx.runtime.get_session(r, uid, touch=True)
        if s:
            out.append((s["name"], s.get("probe", {}).get("duration")))
    return out


async def render_basket(bot, ctx, uid, dlg):
    refs = dlg.data["refs"]
    await edit_safe(bot, dlg.chat_id, dlg.msg_id, U.merge_text(_basket_items(ctx, uid, refs)), U.merge_kb(dlg.ref, len(refs)))


@router.callback_query(F.data.startswith("c:a_merge:"))
async def cb_merge(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if await need_session(cb, ctx, ref):
        uid = cb.from_user.id
        _dialog(ctx, uid, "merge", ref, cb.message.chat.id, cb.message.message_id, minutes=10, refs=[ref])
        await render_basket(bot, ctx, uid, ctx.dialogs.get(uid, "merge"))
        await cb.answer()


async def add_to_basket(bot: Bot, ctx, uid: int, new_ref: str, status_msg: Message) -> bool:
    """بيتنادى من file_router لما يوصل ملف صوت وفيه سلة دمج مفتوحة."""
    dlg = ctx.dialogs.get(uid, "merge")
    if not dlg:
        return False
    await safe_delete(status_msg)
    if len(dlg.data["refs"]) >= MAX_MERGE:
        await bot.send_message(uid, f"⚠️ الحد الأقصى {MAX_MERGE} ملفات في الدمج.")
        return True
    dlg.data["refs"].append(new_ref)
    dlg.expires = time.time() + 600
    await render_basket(bot, ctx, uid, dlg)
    return True


@router.callback_query(F.data.startswith("a:mv:"))
async def cb_move(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, i, d = cb.data.split(":")
    dlg = ctx.dialogs.get(cb.from_user.id, "merge")
    if not dlg or dlg.ref != ref:
        return await cb.answer("⏰ السلة انتهت — ابدأ الدمج تاني.", show_alert=True)
    refs, i = dlg.data["refs"], int(i)
    j = i - 1 if d == "u" else i + 1
    if 0 <= i < len(refs) and 0 <= j < len(refs):
        refs[i], refs[j] = refs[j], refs[i]
    await render_basket(bot, ctx, cb.from_user.id, dlg)
    await cb.answer()


@router.callback_query(F.data.startswith("a:mrm:"))
async def cb_remove(cb: CallbackQuery, bot: Bot, ctx):
    _, _, ref, i = cb.data.split(":")
    dlg = ctx.dialogs.get(cb.from_user.id, "merge")
    if not dlg or dlg.ref != ref:
        return await cb.answer("⏰ السلة انتهت — ابدأ الدمج تاني.", show_alert=True)
    if len(dlg.data["refs"]) > 1 and 0 <= int(i) < len(dlg.data["refs"]):
        dlg.data["refs"].pop(int(i))
    await render_basket(bot, ctx, cb.from_user.id, dlg)
    await cb.answer()


@router.callback_query(F.data == "a:noop")
async def cb_noop(cb: CallbackQuery):
    await cb.answer()


@router.callback_query(F.data.startswith("a:mgo:"))
async def cb_merge_go(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    uid = cb.from_user.id
    dlg = ctx.dialogs.get(uid, "merge")
    if not dlg or dlg.ref != ref:
        return await cb.answer("⏰ السلة انتهت — ابدأ الدمج تاني.", show_alert=True)
    refs = list(dlg.data["refs"])
    if len(refs) < 2:
        return await cb.answer("محتاج ملفين على الأقل — ابعت ملف صوت تاني.", show_alert=True)
    ctx.runtime.update_session(ref, op={"type": "merge", "refs": refs})
    await ask_name(bot, ctx, uid, ref, dlg.chat_id, dlg.msg_id, extra=f"🧩 دمج <b>{len(refs)}</b> ملفات بالترتيب اللي اخترته")
    await cb.answer()


# =================================================== اسم الناتج
def plan(ctx, uid, s, op):
    """(الامتداد، الاسم الافتراضي بدون امتداد)"""
    stem, src_ext = split_ext(s["name"])
    t = op["type"]
    if t == "convert":
        ext = A.FORMATS[op["fmt"]]["ext"]
    elif t == "denoise":
        ext = src_ext if src_ext.lower() in A.EXT_TO_FMT else ".mp3"
    elif t == "merge":
        sess = [ctx.runtime.get_session(r, uid, touch=False) for r in op["refs"]]
        sess = [x for x in sess if x]
        copy = len(sess) == len(op["refs"]) and A.can_copy_merge([x.get("probe", {}) for x in sess], [x["name"] for x in sess])
        ext = src_ext if copy else ".mp3"
    else:
        ext = src_ext or ".mp3"
    return ext, A.default_name(stem, op, ext, src_ext)


async def ask_name(bot, ctx, uid, ref, chat_id, msg_id, extra=""):
    s = ctx.runtime.get_session(ref, uid)
    if not s or not s.get("op"):
        return await edit_safe(bot, chat_id, msg_id, EXPIRED, None)
    ext, base = plan(ctx, uid, s, s["op"])
    shown = A.final_name(base, ext) if s["op"]["type"] != "split" else A.final_name(base + " (part1)", ext)
    _dialog(ctx, uid, "outname", ref, chat_id, msg_id)
    await edit_safe(bot, chat_id, msg_id, U.name_prompt(shown, extra), U.name_kb(ref))


@router.callback_query(F.data.startswith("a:skip:"))
async def cb_skip(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if await need_session(cb, ctx, ref):
        await cb.answer()
        await start_op(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id, None)


@router.message(F.text, ~F.text.startswith("/"), ~F.text.in_(K.MAIN_LABELS), HasDialog("outname"))
async def on_name_text(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    dlg = ctx.dialogs.get(uid, "outname")
    if ctx.store.get_setting(uid, "clean_chat"):
        await safe_delete(msg)
    await start_op(bot, ctx, uid, dlg.ref, dlg.chat_id, dlg.msg_id, msg.text)


# =================================================== التنفيذ
async def start_op(bot, ctx, uid, ref, chat_id, msg_id, typed):
    ctx.dialogs.clear(uid)
    s = ctx.runtime.get_session(ref, uid)
    if not s or not s.get("op"):
        return await edit_safe(bot, chat_id, msg_id, EXPIRED, None)
    op = dict(s["op"])
    settings = ctx.store.all_settings(uid)
    title = A.TITLES[op["type"]]

    async def run(job: Job):
        await _execute(job, bot, ctx, uid, ref, op, chat_id, msg_id, typed, settings)

    job = Job(user_id=uid, chat_id=chat_id, msg_id=msg_id, title=title, run=run)
    pos = await ctx.queue.submit(job)
    if pos == 0:
        await edit_safe(bot, chat_id, msg_id, f"⚙️ <b>{title}</b>\nبدأت…", K.job_controls(job.id))


async def _execute(job, bot, ctx, uid, ref, op, chat_id, msg_id, typed, settings):
    s = ctx.runtime.get_session(ref, uid)
    if not s:
        raise UserError(EXPIRED)
    t, title = op["type"], A.TITLES[op["type"]]
    srcs = [ref] if t != "merge" else op["refs"]
    sess = [ctx.runtime.get_session(r, uid) for r in srcs]
    if any(x is None or not Path(x["local"]).is_file() for x in sess):
        raise UserError("واحد من الملفات اتمسح من السيرفر (تنظيف المساحة) — ابعته تاني.")
    jobdir = ctx.cfg.jobs_dir / job.id
    jobdir.mkdir(parents=True, exist_ok=True)
    job.add_cleanup(lambda: shutil.rmtree(jobdir, ignore_errors=True))

    src = Path(s["local"])
    probe = s.get("probe", {})
    dur = probe.get("duration")
    ext, default_base = plan(ctx, uid, s, op)
    base = typed.strip() if typed and typed.strip() else default_base
    rep = Reporter(bot, chat_id, msg_id, markup=K.job_controls(job.id))
    t0 = time.monotonic()

    async def prog(pct, label=None):
        await rep.update(f"⚙️ <b>{title}</b>\n{label + chr(10) if label else ''}{bar(pct)}\n⏱ {human_elapsed(time.monotonic() - t0)}")

    await rep.update(f"⚙️ <b>{title}</b>\nبجهّز…", force=True)
    outputs: list[Path] = []

    if t == "convert":
        dst = jobdir / A.final_name(base, ext)
        rc, err = await run_ffmpeg(job, A.convert_args(src, dst, op["fmt"], op.get("kbps"), op["ch"]), dur, prog)
        if rc != 0:
            raise UserError("فشل التحويل: " + esc(short_error(err)))
        outputs = [dst]

    elif t == "cut":
        dst = jobdir / A.final_name(base, ext)
        length = op["end"] - op["start"]
        rc, err = await run_ffmpeg(job, A.cut_args(src, dst, op["start"], op["end"], copy=True), length, prog)
        if rc != 0:   # بعض الصيغ مبتقبلش القص بالنسخ — نعيد الترميز
            rc, err = await run_ffmpeg(job, A.cut_args(src, dst, op["start"], op["end"], copy=False), length, prog)
        if rc != 0:
            raise UserError("فشل القص: " + esc(short_error(err)))
        outputs = [dst]

    elif t == "split":
        segs = A.segments(op["points"], dur)
        for i, (a, b_) in enumerate(segs, 1):
            dst = jobdir / A.final_name(f"{base} (part{i})", ext)

            async def seg_prog(pct, i=i):
                await prog(((i - 1) + pct / 100) / len(segs) * 100, f"الجزء {i}/{len(segs)}")
            rc, err = await run_ffmpeg(job, A.cut_args(src, dst, a, b_, copy=True), b_ - a, seg_prog)
            if rc != 0:
                rc, err = await run_ffmpeg(job, A.cut_args(src, dst, a, b_, copy=False), b_ - a, seg_prog)
            if rc != 0:
                raise UserError(f"فشل تقسيم الجزء {i}: " + esc(short_error(err)))
            outputs.append(dst)

    elif t == "merge":
        paths = [Path(x["local"]) for x in sess]
        total = sum((x.get("probe", {}).get("duration") or 0) for x in sess)
        dst = jobdir / A.final_name(base, ext)
        if ext != ".mp3" or A.can_copy_merge([x.get("probe", {}) for x in sess], [x["name"] for x in sess]):
            lst = jobdir / "list.txt"
            A.write_concat_list(paths, lst)
            rc, err = await run_ffmpeg(job, A.merge_copy_args(lst, dst), total, prog)
        else:
            rc, err = 1, ""
        if rc != 0:
            dst = jobdir / A.final_name(base, ".mp3")
            rc, err = await run_ffmpeg(job, A.merge_reencode_args(paths, dst), total, prog)
        if rc != 0:
            raise UserError("فشل الدمج: " + esc(short_error(err)))
        outputs = [dst]

    elif t == "denoise":
        dst = jobdir / A.final_name(base, ext)
        if op.get("mode") == "ai":
            clean = await _ai_denoise(job, src, jobdir, rep)
            fmt = A.fmt_from_name(dst.name)
            rc, err = await run_ffmpeg(job, A.convert_args(clean, dst, fmt, A.default_kbps(fmt, None, 192), "keep"), dur, prog)
        else:
            rc, err = await run_ffmpeg(job, A.denoise_args(src, dst, A.source_kbps(probe)), dur, prog)
        if rc != 0:
            raise UserError("فشلت التنقية: " + esc(short_error(err)))
        outputs = [dst]

    # ---- الرفع ----
    sizes = 0
    for i, out in enumerate(outputs, 1):
        size = out.stat().st_size
        sizes += size
        out_probe = await probe_file(out, "audio", out.name)

        def render(el, i=i, size=size):
            return (f"⬆️ <b>{title}</b>\nجاري الرفع {f'({i}/{len(outputs)}) ' if len(outputs) > 1 else ''}"
                    f"{human_size(size)}…\n⏱ {human_elapsed(el)}")
        async with ticker(rep, render, interval=4.0):
            await deliver(bot, ctx.store, chat_id, out, "audio", out_probe, settings)

    names = "\n".join(f"• <code>{esc(o.name)}</code>" for o in outputs[:12])
    await rep.update(f"✅ <b>{title} تم</b>\n{names}\n📦 {human_size(sizes)} • ⏱ {human_elapsed(time.monotonic() - t0)}",
                     K.after_job(ref), force=True)


async def _ai_denoise(job: Job, src: Path, jobdir: Path, rep: Reporter) -> Path:
    """DeepFilterNet (تجريبي): بيتثبّت lazily. أي فشل بيرجّع رسالة واضحة بنصيحة النمط السريع."""
    hint = "جرّب النمط السريع ⚡ — بيشتغل على كل البيئات."
    await rep.update("🤖 <b>تنقية الصوت</b>\nبجهّز DeepFilterNet (أول مرة بتاخد كام دقيقة)…", force=True)
    rc, _o, _e = await run_cmd(job, sys.executable, "-c", "import df")
    if rc != 0:
        rc, _o, err = await run_cmd(job, sys.executable, "-m", "pip", "install", "-q", "deepfilternet", timeout=1800)
        if rc != 0:
            log.warning("deepfilternet install failed: %s", (err or b"")[-200:])
            raise UserError("معرفتش أنزّل DeepFilterNet على البيئة دي. " + hint)
    wav = jobdir / "in48k.wav"
    rc, err = await run_ffmpeg(job, ["-i", src, "-vn", "-ac", "1", "-ar", "48000", wav])
    if rc != 0:
        raise UserError("فشل تجهيز الملف للتنقية: " + esc(short_error(err)))
    outdir = jobdir / "df"
    outdir.mkdir(exist_ok=True)
    code = "import sys; sys.argv=['deepFilter']+sys.argv[1:]; from df.enhance import run; run()"
    rc, _o, err = await run_cmd(job, sys.executable, "-c", code, "-o", outdir, wav, timeout=3600)
    outs = sorted(outdir.glob("*.wav"))
    if rc != 0 or not outs:
        log.warning("deepfilternet run failed: %s", (err or b"")[-300:])
        raise UserError("DeepFilterNet فشل في التشغيل. " + hint)
    return outs[0]
