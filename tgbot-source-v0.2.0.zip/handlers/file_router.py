"""استقبال أي ملف: تحميل للسيرفر المحلي (مع عدّاد) ← تحليل ← كارت بيانات + أزرار حسب النوع."""
from __future__ import annotations

import logging
import mimetypes
import time
from dataclasses import dataclass
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery, Message

from core import registry as R
from core.probe import detect_kind, probe_file
from core.progress import Reporter, download_render, edit_safe, ticker
from core.smart import LIMIT, hints
from core.utils import disk_free, human_size, sanitize_filename, split_ext
from handlers.common import drop_session_files, need_session
from handlers import audio as audio_h, rename as rename_h
from ui import keyboards as K, texts as T

log = logging.getLogger("files")
router = Router(name="files")

MIME_EXT = {"audio/mpeg": ".mp3", "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/ogg": ".ogg",
            "audio/x-wav": ".wav", "audio/wav": ".wav", "audio/flac": ".flac", "video/mp4": ".mp4",
            "image/jpeg": ".jpg", "application/pdf": ".pdf"}


@dataclass
class FileRef:
    file_id: str
    unique_id: str
    name: str
    size: int
    mime: str
    kind: str
    compressed: bool = False


def _with_ext(name: str, mime: str) -> str:
    if split_ext(name)[1]:
        return name
    ext = MIME_EXT.get(mime or "") or mimetypes.guess_extension(mime or "") or ""
    return name + ext


def extract(msg: Message) -> FileRef | None:
    mid = msg.message_id
    if msg.document:
        d = msg.document
        name, mime, kind_src = d.file_name or f"document_{mid}", d.mime_type or "", d
    elif msg.audio:
        a = msg.audio
        base = a.file_name or (f"{a.performer} - {a.title}" if a.performer and a.title else a.title) or f"audio_{mid}"
        name, mime, kind_src = base, a.mime_type or "audio/mpeg", a
    elif msg.video:
        v = msg.video
        name, mime, kind_src = v.file_name or f"video_{mid}", v.mime_type or "video/mp4", v
    elif msg.voice:
        v = msg.voice
        name, mime, kind_src = f"voice_{mid}.ogg", v.mime_type or "audio/ogg", v
    elif msg.video_note:
        v = msg.video_note
        name, mime, kind_src = f"video_note_{mid}.mp4", "video/mp4", v
    elif msg.animation:
        v = msg.animation
        name, mime, kind_src = v.file_name or f"animation_{mid}.mp4", v.mime_type or "video/mp4", v
    elif msg.photo:
        p = msg.photo[-1]
        return FileRef(p.file_id, p.file_unique_id, f"photo_{mid}.jpg", p.file_size or 0, "image/jpeg", "image", True)
    else:
        return None
    name = sanitize_filename(_with_ext(name, mime), fallback=f"file_{mid}")
    return FileRef(kind_src.file_id, kind_src.file_unique_id, name, kind_src.file_size or 0, mime,
                   detect_kind(name, mime))


def card_text_and_markup(ctx, sess: dict):
    kind, probe = sess["kind"], sess.get("probe", {})
    lines = [tuple(x) for x in probe.get("lines", [])]
    hs = hints(kind, sess.get("size", 0), probe, sess["name"], sess.get("compressed", False),
               disk_free(ctx.cfg.work))
    soon = []
    for a in R.for_kind(kind, False):
        if a.section == "meta":
            continue
        lab = a.label.split(" ", 1)[-1]
        if lab not in soon:
            soon.append(lab)
    text = T.file_card(kind, sess["name"], lines, hs, soon[:6])
    return text, K.file_card(sess["_ref"], kind, sess["name"])


async def show_card(bot: Bot, ctx, uid: int, ref: str, chat_id: int, msg_id: int):
    sess = ctx.runtime.get_session(ref, uid)
    if not sess:
        await edit_safe(bot, chat_id, msg_id, "⏰ الكارت انتهت صلاحيته — ابعت الملف تاني 📎", None)
        return
    ctx.dialogs.clear(uid)
    text, mk = card_text_and_markup(ctx, sess)
    await edit_safe(bot, chat_id, msg_id, text, mk)


@router.message(F.document | F.audio | F.video | F.voice | F.video_note | F.photo | F.animation)
async def on_file(msg: Message, bot: Bot, ctx):
    uid = msg.from_user.id
    ref_f = extract(msg)
    if not ref_f:
        return
    if ref_f.size and ref_f.size > LIMIT:
        return await msg.reply(f"⛔ الملف ({human_size(ref_f.size)}) أكبر من حد تليجرام <b>2GB</b>. "
                               "قسّمه أو صغّره وابعته تاني.")
    free = disk_free(ctx.cfg.work)
    if ref_f.size and free < ref_f.size * 2.5:
        return await msg.reply(f"⛔ مساحة الديسك ({human_size(free)} فاضية) مش كفاية لملف "
                               f"{human_size(ref_f.size)} (محتاج ~2.5× حجمه). جرّب بعد ما أنضّف، أو أعد تشغيل الجلسة.")

    status = await msg.reply("⏳ <b>بستلم الملف…</b>")
    reporter = Reporter(bot, status.chat.id, status.message_id)
    t0 = time.time()
    try:
        render = download_render(ref_f.size, [ctx.cfg.server_dir, ctx.cfg.server_tmp], t0, "بحمّل ملفك")
        async with ticker(reporter, render, interval=3.0):
            f = await bot.get_file(ref_f.file_id)
    except TelegramBadRequest as e:
        if "too big" in str(e).lower():
            return await edit_safe(bot, status.chat.id, status.message_id,
                                   "❌ تليجرام رفض الملف (كبير) — معناها إن البوت مش شغّال على السيرفر المحلي. "
                                   "شغّل خلية السيرفر في الـ notebook وأعد المحاولة.", None)
        log.warning("get_file failed: %s", str(e)[:120])
        return await edit_safe(bot, status.chat.id, status.message_id, "❌ معرفتش أجيب الملف من تليجرام. جرّب تبعته تاني.", None)
    except Exception as e:
        log.warning("get_file error: %s", type(e).__name__)
        return await edit_safe(bot, status.chat.id, status.message_id,
                               "❌ حصل خطأ في التحميل (السيرفر المحلي ممكن يكون واقف). شوف /status وجرّب تاني.", None)

    local = Path(f.file_path or "")
    if not local.is_absolute():
        local = ctx.cfg.server_dir / local
    if not local.is_file():
        return await edit_safe(bot, status.chat.id, status.message_id,
                               "❌ السيرفر مرجعش مسار ملف محلي. اتأكد إنه شغّال بوضع <code>--local</code>.", None)

    await edit_safe(bot, status.chat.id, status.message_id, "🔎 بحلل الملف…", None)
    probe = await probe_file(local, ref_f.kind, ref_f.name, ref_f.mime)
    ref = ctx.runtime.new_session(uid, {
        "file_id": ref_f.file_id, "name": ref_f.name, "size": local.stat().st_size, "mime": ref_f.mime,
        "kind": ref_f.kind, "local": str(local), "probe": probe, "compressed": ref_f.compressed,
        "chat_id": status.chat.id})

    if ref_f.kind == "audio" and await audio_h.add_to_basket(bot, ctx, uid, ref, status):
        return
    if ctx.dialogs.pop_intent(uid) == "rename":
        return await rename_h.show_rename_prompt(bot, ctx, uid, ref, status.chat.id, status.message_id)
    await show_card(bot, ctx, uid, ref, status.chat.id, status.message_id)


# ---------------- أزرار الكارت ----------------
@router.callback_query(F.data.startswith("c:card:"))
async def cb_card(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    if await need_session(cb, ctx, ref):
        await show_card(bot, ctx, cb.from_user.id, ref, cb.message.chat.id, cb.message.message_id)
        await cb.answer()


@router.callback_query(F.data.startswith("c:info:"))
async def cb_info(cb: CallbackQuery, bot: Bot, ctx):
    ref = cb.data.split(":", 2)[2]
    sess = await need_session(cb, ctx, ref)
    if not sess:
        return
    p = sess.get("probe", {})
    text = T.file_details(sess["name"], [tuple(x) for x in p.get("lines", [])], [tuple(x) for x in p.get("extra", [])])
    await edit_safe(bot, cb.message.chat.id, cb.message.message_id, text, K.details_view(ref))
    await cb.answer()


@router.callback_query(F.data.startswith("c:close:"))
async def cb_close(cb: CallbackQuery, ctx):
    ref = cb.data.split(":", 2)[2]
    ctx.dialogs.clear(cb.from_user.id)
    sess = ctx.runtime.get_session(ref, cb.from_user.id, touch=False)
    if sess:
        drop_session_files(ctx, ref)
    try:
        await cb.message.delete()
    except Exception:
        pass
    await cb.answer("اتقفل ✅ ومسحت الملف المؤقت")
